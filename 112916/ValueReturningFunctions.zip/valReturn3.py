#Schaffer Stewart
#11/29/16
#Value Returning Workshop #3

def cube(num):
    return num * num * num

result = cube(4)
print(result)
