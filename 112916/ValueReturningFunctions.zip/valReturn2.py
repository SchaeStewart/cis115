#Schaffer Stewart
#11/29/16
#Value Returning Workshop #2

import random

def half(number):
    number = number/2
    return number

number = random.randrange(1, 100)

result = half(number)
print(result)

