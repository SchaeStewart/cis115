#Schaffer Stewart
#11/29/16
#Value Returning Workshop #1

import random

rand = random.randrange(1, 100)

print(rand)
