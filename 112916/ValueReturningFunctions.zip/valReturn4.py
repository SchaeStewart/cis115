#Schaffer Stewart
#11/29/16
#Value Returning Workshop #4

def times_ten(number):
    return number * 10

result = times_ten(10)
print(result)
