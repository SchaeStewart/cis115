#Schaffer Stewart
#11/29/16
#Value Returning Workshop #5

def get_first_name():
    first_name = str(input("Please enter your first name "))
    return first_name

first_name = get_first_name()
print(first_name)
